import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  categories: {[category: string]: any[]} = {};
  menuItems: any[] = [];
  cartItems: any[] = [];

  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.getMenuItems();
  }

  getMenuItems() {
    this.http.get<any[]>('https://gist.githubusercontent.com/RudarDaman/39349c73d0693a5cd082a47818981a59/raw/c4fedf7ac2a23cb32bf37c83f7af7f5efc08828f/menu.json')
      .subscribe((data) => {
        console.log(data);
        this.menuItems = data;

        this.menuItems.forEach((item: any) => {
          if (!this.categories[item.category]) {
            this.categories[item.category] = [];
          }
          this.categories[item.category].push(item);
        });
      });
  }

  updateTotal(): number {
    this.cartItems = JSON.parse(localStorage.getItem('cartItems') || '[]');
    let total = 0;
    this.cartItems.forEach((item: any) => {
      total += item.price;
    });
    return total;
  }

  addItemToCart(item: any) {
    this.cartItems = JSON.parse(localStorage.getItem('cartItems') || '[]');
    this.cartItems.push(item);
    localStorage.setItem('cartItems', JSON.stringify(this.cartItems));
  }

  removeItemFromCart(item: any) {
    this.cartItems = JSON.parse(localStorage.getItem('cartItems') || '[]');
    const index = this.cartItems.findIndex((cartItem) => item.id === cartItem.id);
    if (index !== -1) {
      this.cartItems.splice(index, 1);
      localStorage.setItem('cartItems', JSON.stringify(this.cartItems));
    }
  }

  scrollToCategory(category: string) {
    const categoryData = this.categories[category];
    const categoryHeading = document.getElementById(category);
    if (categoryHeading != null) {
      categoryHeading.scrollIntoView({ behavior: 'smooth' });
    }
  }
}
